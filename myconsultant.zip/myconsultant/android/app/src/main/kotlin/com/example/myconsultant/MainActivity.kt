package com.example.myconsultant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
